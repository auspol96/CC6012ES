﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MovieApp.Data;
using MovieApp.Models;
using System.Threading.Tasks;

namespace MovieApp.Controllers
{
    public class MovieController : Controller
    {
        private readonly ApplicationDbContext _context;

        public MovieController(ApplicationDbContext context)
        {
            _context = context;
        }

        //Start Create
        [HttpGet]
        public IActionResult Create()
        {
            return View(); // Show the empty form
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Movie movie)
        {
            if (ModelState.IsValid)
            {
                _context.Movies.Add(movie);         // Add the new movie to the context
                await _context.SaveChangesAsync();  // Save to the database
                return RedirectToAction(nameof(Index)); // Redirect back to movie list
            }

            return View(movie); // If validation fails, return the same form
        }
        //End Create

        //Start Edit
        [HttpGet]
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)   //This checks whether the incoming ID is null (i.e., not provided in the URL).
                return NotFound();

            var movie = await _context.Movies.FindAsync(id);   //This line attempts to find the movie in the database with that ID
            if (movie == null)
                return NotFound();

            return View(movie);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Movie movie)
        {
            if (id != movie.Id)
                return NotFound();

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(movie); // This movie object represents an existing, and i want to modify. 
                    await _context.SaveChangesAsync(); // Save changes to DB
                }
                catch (DbUpdateConcurrencyException) //this block is valid when the record suddenly deleted/updated by others.
                {
                    if (!_context.Movies.Any(e => e.Id == id))
                        return NotFound();
                    else
                        throw;
                }

                return RedirectToAction(nameof(Index)); //Send user back to the movie list page
            }

            return View(movie); // Return with validation errors if any
        }
        //End Edit.

        public async Task<IActionResult> Index(string sortOrder, string searchString, int? pageNumber)
        {
            ViewData["CurrentFilter"] = searchString;
            ViewData["TitleSortParm"] = String.IsNullOrEmpty(sortOrder) ? "title_desc" : "";
            ViewData["DateSortParm"] = sortOrder == "Date" ? "date_desc" : "Date";
            ViewData["PriceSortParm"] = sortOrder == "Price" ? "price_desc" : "Price";

            var movies = from m in _context.Movies select m;

            if (!string.IsNullOrWhiteSpace(searchString))
            {
                movies = movies.Where(s => s.Title.Contains(searchString));
            }

            switch (sortOrder)
            {
                case "title_desc":
                    movies = movies.OrderByDescending(s => s.Title);
                    break;
                case "Date":
                    movies = movies.OrderBy(s => s.ReleaseDate);
                    break;
                case "date_desc":
                    movies = movies.OrderByDescending(s => s.ReleaseDate);
                    break;
                case "Price":
                    movies = movies.OrderBy(s => s.Price);
                    break;
                case "price_desc":
                    movies = movies.OrderByDescending(s => s.Price);
                    break;
                default:
                    movies = movies.OrderBy(s => s.Title);
                    break;
            }

            int pageSize = 3;
            return View(await PaginatedList<Movie>.CreateAsync(movies.AsNoTracking(), pageNumber ?? 1, pageSize));
        }

    }
}
